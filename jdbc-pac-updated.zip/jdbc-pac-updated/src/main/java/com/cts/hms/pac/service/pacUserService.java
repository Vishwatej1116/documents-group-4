package com.cts.hms.pac.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.hms.pac.dao.pacUserDao;
import com.cts.hms.pac.entity.pacUser;

@Service
public class pacUserService {
	@Autowired
	private pacUserDao udao;
	
	public int create(pacUser pacuser)
	{
		return udao.create(pacuser);
	}

	public List<pacUser> read()
	{
		return udao.read();
	}
	
	/*public pacUser readbyUsername(String userName)
	{
		return udao.readbyUsername(userName);
	} */

	public pacUser read(String userName)
	{
		return udao.read(userName);
	}
	
	public  pacUser fetchUserByUserName(String tempUserId, String tempPsw) {
		// TODO Auto-generated method stub
		return udao.fetchUserByUserName(tempUserId, tempPsw);
	}

	public int update(pacUser pacuser)
	{
		return udao.update(pacuser);
	}

	public int delete(Long id)
	{
		return udao.delete(id);
	}
}


