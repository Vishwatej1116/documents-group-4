package com.cts.hms.pac.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.hms.pac.entity.Slots;
import com.cts.hms.pac.service.SlotsService;


@RestController
@CrossOrigin({"http://localhost:4200","*"})
public class SlotsController {
	@Autowired
	private SlotsService ss;
	
	@PostMapping("/Slots")
	public int addSlots(@RequestBody Slots slots)
	{
		
		return ss.create(slots);
	}
	
	@GetMapping("/Slots")
	public List<Slots> getAllSlotss()
	{
		return ss.read();
	}
	
	/*@GetMapping("/Slots/{id}")
	public Slots findSlotsById(@PathVariable Long id)
	{
		return ss.read(id);
	} */
	
	@GetMapping("/Slots/{userName}")
	public Slots findSlotsByUsername(@PathVariable String userName)
	{
		return ss.readbyUsername(userName);
	}
	
	@PutMapping("/Slots")
	public int modifySlots(@RequestBody Slots slots)
	{
		return ss.update(slots);
	}
	
	@DeleteMapping("/Slots/{id}")
	public int removeSlots(@PathVariable Long id)
	{
		return ss.delete(id);
	}
}

