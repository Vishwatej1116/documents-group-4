import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PacUserService } from '../pac-user.service';
import { Slots } from '../slots';
import { Pacuser } from '../pacuser';
import { Vcenters } from '../vcenters';

@Component({
  selector: 'app-user-homepage',
  templateUrl: './user-homepage.component.html',
  styleUrls: ['./user-homepage.component.css']
})
export class UserHomepageComponent implements OnInit {
  userTable:boolean = false;
  vCenters:boolean = false
  bookSlot:boolean = false
  helpInfo:boolean = false
  showVCenter:boolean = false
  help:boolean = false
  profile:boolean = false
  pinCode:number=0
  slotDate: Date | undefined
  slotTime: string=''
  vType: string=''
  vCentersData:any =[]
  bookData :any = {}
  userData :any = {}
  vcenters:Vcenters= new Vcenters();
  pacuser:Pacuser= new Pacuser();
  slots:Slots= new Slots();
  message : any;
  i : any
  sampleData: any
  bookingData: any=[];
  usingData: any=[];
  constructor(private router: Router,public service: PacUserService) { }

  ngOnInit() {
    
  }

  onBtnClick(value:string){
    if(value == "showVCenter"){
      this.userTable = false
      this.showVCenter = true
      this.bookSlot = false
      this.profile = false
      this.help = false
    }
    else if(value == "userTable"){
      this.userTable = true
      this.showVCenter = false
      this.bookSlot = false
      this.profile = false
      this.help = false
    }
    else if(value == "profile"){
      this.userTable = false
      this.showVCenter = false
      this.bookSlot = false
      this.profile = true
      this.help = false
    }
    else if(value == "help"){
      this.userTable = false
      this.showVCenter = false
      this.bookSlot = false
      this.profile = false
      this.help = true
    }
    else {
      this.slots.centerName= value
      this.userTable = false
      this.showVCenter = false
      this.bookSlot = true
      this.profile = false
      this.help = false
    }

  }
  public getBookingDatabyUsername(){
    
    var name=this.service.getUserName();
    let response1 = this.service.getBookingDatabyUsername(name);
     response1.subscribe(data => this.bookData = data);
     
     alert("hello...  "  +name)
    
  }

  public getUserDatabyId(){
    var uname=this.service.getUserName();
    let response1 = this.service.getUserDatabyId(uname);
    response1.subscribe(data => this.userData = data);
     
     alert("hello...  " +uname)
    
  }

   public findVcentersByPinCode(){
   let response = this.service.getVcentersByPinCode(this.vcenters.pinCode);
   response.subscribe(data => this.vCentersData = data);
  }

public getBookingData(){
  let response2=this.service.getBookingData();
  response2.subscribe(data=>this.bookingData=data)
}

public getUsingData(){
  let response2=this.service.getUsingData();
  response2.subscribe(data=>this.usingData=data)
}


  public confirmSlot(){
    
    console.log(this.slots)
    this.slots.userName= this.service.getUserName();
    
    let reponse = this.service.doSlotBook(this.slots);
      reponse.subscribe(data => {
        this.message=data
      },
error => { alert("You have already booked vaccine slot")}

      )
  }

}
